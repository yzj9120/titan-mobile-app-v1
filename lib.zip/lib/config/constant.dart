class Constant {
  static const String copyFileStatus = "copyFileStatus";
  static const String cancelPath = "cancelPath";
  static const String oldPath = "oldPath";
  static const String newStorePath = "newStorePath";
  static const String failurePath = "failurePath";
  static const String adNextTimestamp = "adNextTimestamp";
  static const String userCode = "userCode";
  static const String userAddress = "userAddress";
}
