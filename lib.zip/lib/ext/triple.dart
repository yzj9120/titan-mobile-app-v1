class Triple<FIRST, SECOND, THIRD> {
  final FIRST first;
  final SECOND second;
  final THIRD third;

  Triple(this.first, this.second, this.third);
}
