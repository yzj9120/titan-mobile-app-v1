class Pair<FIRST, SECOND> {
  FIRST first;
  SECOND second;

  Pair(this.first, this.second);
}
