import 'dart:core';

class LaunchAfterCommand {
  static Future<void> setUp() async {}
}
